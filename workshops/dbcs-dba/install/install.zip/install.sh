#!/bin/bash

# extract files
unzip opc_installer.zip

# install data
sqlplus system/Alpha2018_@pdb1 << EOF

create tablespace alpha
nologging
datafile '/u02/app/oracle/oradata/ORCL/PDB1/alpha.dbf'
size 10m autoextend on
next 10m maxsize unlimited
extent management local;

create user alpha identified by Alpha2018_ default tablespace alpha;

grant dba to alpha;

create directory oracle as '/home/oracle';

grant all on directory oracle to public;

EOF

# import data
impdp alpha/Alpha2018_@pdb1 directory=oracle dumpfile=alpha.dmp remap_tablespace=users:alpha

# stop annoying pop up message about yum updates
spawn sudo su -

send "echo X-GNOME-Autostart-enabled=false>>/etc/xdg/autostart/gpk-update-icon.desktop\r"
expect "$ "
sleep 1
send "exit\r"

