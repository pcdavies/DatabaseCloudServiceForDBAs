#!/bin/bash

# create user and tablespace
sqlplus system/Alpha2018_@pdb1 << EOF

create tablespace alpha
nologging
datafile '/u02/app/oracle/oradata/ORCL/PDB1/alpha.dbf'
size 10m autoextend on
next 10m maxsize unlimited
extent management local;

create user alpha identified by Alpha2018_ default tablespace alpha;

grant dba to alpha;

create directory oracle as '/home/oracle';

grant all on directory oracle to public;

EOF

# import data
impdp alpha/Alpha2018_@pdb1 directory=oracle dumpfile=alpha.dmp remap_tablespace=users:alpha


