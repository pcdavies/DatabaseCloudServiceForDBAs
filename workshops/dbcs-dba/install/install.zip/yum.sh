#!/bin/bash

yum -y groupinstall "Desktop" "General Purpose Desktop"
yum -y install tigervnc-server firefox flash-plugin
yum clean all
yum clean metadata
tar -cvxf backuprepo.tar.gz *
rm pub*
rm adob*

# stop annoying pop up message about yum updates
spawn sudo su -
send "echo X-GNOME-Autostart-enabled=false>>/etc/xdg/autostart/gpk-update-icon.desktop\r"
expect "$ "
sleep 1
send "exit\r"
